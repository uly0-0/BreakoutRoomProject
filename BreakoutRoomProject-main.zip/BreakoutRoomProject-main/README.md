# BreakoutRoomProject

How to Run Program for Testing
1. Run systemserver.py 
    ex. python systemser.py
2. run studentgui.py
3. press connect to server on gui
    - you should see a message on system server window indicating connection was successful

TO DO LIST
* fix TTL issue
* display movies on screen in gui
* figure out how instructor.py works and document
* creating new breakout rooms
* instructor should have own gui

Current Issues
- connection issues : gui crashes and disconnects right after sending message or requesting breakout room. Messages sent get received by server but connection gets killed. Might be a Time to live issue thats killing connection. 

